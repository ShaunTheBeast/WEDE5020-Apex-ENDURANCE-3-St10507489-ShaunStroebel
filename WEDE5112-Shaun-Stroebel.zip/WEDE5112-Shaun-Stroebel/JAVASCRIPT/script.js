document.addEventListener('DOMContentLoaded', () => {
    // ==========================================================================
    // 1. Dual-Role State & UI Visibility Manager
    // ==========================================================================
    const roleSelect = document.getElementById('userRoleSelect');
    
    // Load saved role or default to 'athlete'
    let currentRole = localStorage.getItem('apex_user_role') || 'athlete';
    
    if (roleSelect) {
        roleSelect.value = currentRole;
        roleSelect.addEventListener('change', (e) => {
            currentRole = e.target.value;
            localStorage.setItem('apex_user_role', currentRole);
            applyRoleState(currentRole);
        });
    }

    function applyRoleState(role) {
        const athleteElements = document.querySelectorAll('.athlete-only');
        const creatorElements = document.querySelectorAll('.creator-only');
        const heroBadge = document.getElementById('heroRoleBadge');

        if (role === 'creator') {
            athleteElements.forEach(el => el.style.display = 'none');
            creatorElements.forEach(el => el.style.display = '');
            if (heroBadge) heroBadge.textContent = 'Route Creator Studio Active';
        } else {
            athleteElements.forEach(el => el.style.display = '');
            creatorElements.forEach(el => el.style.display = 'none');
            if (heroBadge) heroBadge.textContent = 'Athlete Workspace Active';
        }
    }

    applyRoleState(currentRole);

    // ==========================================================================
    // 2. Mobile Navigation Menu Toggle
    // ==========================================================================
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            navLinks.classList.toggle('open');
        });
    }

    // ==========================================================================
    // 3. Discipline Filtering (All, Running, Cycling)
    // ==========================================================================
    const filterBtns = document.querySelectorAll('.filter-btn');
    const filterableItems = document.querySelectorAll('[data-category]');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filterValue = btn.getAttribute('data-filter');

            filterableItems.forEach(item => {
                const categories = item.getAttribute('data-category').split(' ');
                if (filterValue === 'all' || categories.includes(filterValue)) {
                    item.style.display = 'flex';
                    setTimeout(() => { item.style.opacity = '1'; }, 10);
                } else {
                    item.style.opacity = '0';
                    item.style.display = 'none';
                }
            });
        });
    });

    // ==========================================================================
    // 4. Lightbox Modal Gallery Preview
    // ==========================================================================
    const modal = document.getElementById('lightboxModal');
    const modalImg = document.getElementById('lightboxImg');
    const captionText = document.getElementById('lightboxCaption');
    const closeBtn = document.getElementById('lightboxClose');
    const triggers = document.querySelectorAll('.lightbox-trigger');

    triggers.forEach(img => {
        img.addEventListener('click', () => {
            if (modal && modalImg && captionText) {
                modal.classList.add('open');
                modalImg.src = img.src;
                captionText.textContent = img.alt || 'Endurance Route Preview';
            }
        });
    });

    if (closeBtn && modal) {
        closeBtn.addEventListener('click', () => {
            modal.classList.remove('open');
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('open');
            }
        });
    }

    // ==========================================================================
    // 5. Pace & Split Metric Engine (calculator.html)
    // ==========================================================================
    const calcBtn = document.getElementById('calcBtn');
    if (calcBtn) {
        calcBtn.addEventListener('click', calculateMetrics);
    }

    function calculateMetrics() {
        const distanceEl = document.getElementById('calcDistance');
        const hoursEl = document.getElementById('hours');
        const minutesEl = document.getElementById('minutes');
        const secondsEl = document.getElementById('seconds');
        const errorEl = document.getElementById('calcError');

        if (!distanceEl || !hoursEl || !minutesEl || !secondsEl) return;

        const distance = parseFloat(distanceEl.value);
        const hours = parseInt(hoursEl.value) || 0;
        const minutes = parseInt(minutesEl.value) || 0;
        const seconds = parseInt(secondsEl.value) || 0;

        if (errorEl) errorEl.textContent = '';

        const totalSeconds = (hours * 3600) + (minutes * 60) + seconds;

        if (totalSeconds <= 0 || isNaN(totalSeconds)) {
            if (errorEl) errorEl.textContent = 'Please enter a valid time greater than 0.';
            return;
        }

        // Speed calculation (km/h)
        const totalHours = totalSeconds / 3600;
        const speed = (distance / totalHours).toFixed(2);

        // Pace calculation (min/km)
        const secondsPerKm = totalSeconds / distance;
        const paceMin = Math.floor(secondsPerKm / 60);
        const paceSec = Math.floor(secondsPerKm % 60);
        const formattedPace = `${String(paceMin).padStart(2, '0')}:${String(paceSec).padStart(2, '0')}`;

        // 50% Split Calculation
        const splitTotalSec = Math.floor(totalSeconds / 2);
        const splitH = Math.floor(splitTotalSec / 3600);
        const splitM = Math.floor((splitTotalSec % 3600) / 60);
        const splitS = splitTotalSec % 60;
        const formattedSplit = `${String(splitH).padStart(2, '0')}:${String(splitM).padStart(2, '0')}:${String(splitS).padStart(2, '0')}`;

        // Output results
        const speedRes = document.getElementById('speedResult');
        const paceRes = document.getElementById('paceResult');
        const splitRes = document.getElementById('splitResult');

        if (speedRes) speedRes.innerHTML = `${speed} <small>km/h</small>`;
        if (paceRes) paceRes.innerHTML = `${formattedPace} <small>min/km</small>`;
        if (splitRes) splitRes.textContent = formattedSplit;
    }

    // ==========================================================================
    // 6. Persistent Interactive Checklists (plans.html)
    // ==========================================================================
    const checkboxes = document.querySelectorAll('.checklist input[type="checkbox"]');
    
    // Load saved states
    checkboxes.forEach(cb => {
        const savedState = localStorage.getItem(`gear_cb_${cb.id}`);
        if (savedState === 'true') {
            cb.checked = true;
        }

        cb.addEventListener('change', () => {
            localStorage.setItem(`gear_cb_${cb.id}`, cb.checked);
        });
    });

    // ==========================================================================
    // 7. Route Creator Studio Management (creator.html)
    // ==========================================================================
    const routeForm = document.getElementById('routeBuilderForm');
    const tableBody = document.getElementById('creatorTableBody');
    const cancelEditBtn = document.getElementById('cancelEditBtn');

    // Default routes list loaded into LocalStorage if empty
    let customRoutes = JSON.parse(localStorage.getItem('apex_custom_routes')) || [
        { id: 101, name: "Table Mountain Trail Loop", category: "running", distance: 22.5, elevation: 1100, surface: "Singletrack", location: "Cape Town", img: "https://images.unsplash.com/photo-1506744038136-46273834b3fb", desc: "Technical trail ascent." },
        { id: 102, name: "Stellenbosch Vineyard Ride", category: "cycling", distance: 75, elevation: 620, surface: "Asphalt & Gravel", location: "Stellenbosch", img: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8", desc: "Rolling wineland hills." }
    ];

    function saveAndRenderRoutes() {
        localStorage.setItem('apex_custom_routes', JSON.stringify(customRoutes));
        renderTable();
    }

    function renderTable() {
        if (!tableBody) return;
        tableBody.innerHTML = '';

        customRoutes.forEach(route => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><strong>${route.name}</strong><br><small>${route.location}</small></td>
                <td><span class="card-tag ${route.category}-tag">${route.category}</span></td>
                <td>${route.distance} km</td>
                <td>${route.elevation} m</td>
                <td>
                    <button class="btn btn-secondary" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;" onclick="editRoute(${route.id})">Edit</button>
                    <button class="btn btn-primary" style="padding: 0.3rem 0.6rem; font-size: 0.8rem; background-color: var(--accent-red);" onclick="deleteRoute(${route.id})">Delete</button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    if (routeForm) {
        renderTable();

        routeForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const routeId = document.getElementById('routeId').value;
            const name = document.getElementById('routeName').value.trim();
            const location = document.getElementById('routeLocation').value.trim();
            const category = document.getElementById('routeCategory').value;
            const distance = parseFloat(document.getElementById('routeDistance').value);
            const elevation = parseInt(document.getElementById('routeElevation').value);
            const surface = document.getElementById('routeSurface').value.trim();
            const img = document.getElementById('routeImg').value.trim();
            const desc = document.getElementById('routeDesc').value.trim();

            if (!name || !location || isNaN(distance) || isNaN(elevation)) {
                alert('Please fill in all required route fields correctly.');
                return;
            }

            if (routeId) {
                // Update Existing Route
                const idx = customRoutes.findIndex(r => r.id == routeId);
                if (idx !== -1) {
                    customRoutes[idx] = { id: parseInt(routeId), name, location, category, distance, elevation, surface, img, desc };
                }
            } else {
                // Add New Route
                const newRoute = {
                    id: Date.now(),
                    name, location, category, distance, elevation, surface, img, desc
                };
                customRoutes.push(newRoute);
            }

            resetRouteForm();
            saveAndRenderRoutes();
        });
    }

    window.editRoute = function(id) {
        const route = customRoutes.find(r => r.id === id);
        if (!route) return;

        document.getElementById('routeId').value = route.id;
        document.getElementById('routeName').value = route.name;
        document.getElementById('routeLocation').value = route.location;
        document.getElementById('routeCategory').value = route.category;
        document.getElementById('routeDistance').value = route.distance;
        document.getElementById('routeElevation').value = route.elevation;
        document.getElementById('routeSurface').value = route.surface;
        document.getElementById('routeImg').value = route.img;
        document.getElementById('routeDesc').value = route.desc;

        document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-pen text-cyan"></i> Edit Custom Route';
        document.getElementById('saveRouteBtn').textContent = 'Update Route';
        if (cancelEditBtn) cancelEditBtn.style.display = 'inline-block';
    };

    window.deleteRoute = function(id) {
        if (confirm('Are you sure you want to delete this route?')) {
            customRoutes = customRoutes.filter(r => r.id !== id);
            saveAndRenderRoutes();
        }
    };

    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', resetRouteForm);
    }

    function resetRouteForm() {
        if (!routeForm) return;
        routeForm.reset();
        document.getElementById('routeId').value = '';
        document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-plus-circle text-cyan"></i> Build New Custom Route';
        document.getElementById('saveRouteBtn').textContent = 'Publish Route';
        if (cancelEditBtn) cancelEditBtn.style.display = 'none';
    }

    // ==========================================================================
    // 8. Contact Form AJAX Validation (contact.html)
    // ==========================================================================
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            let isValid = true;

            const name = document.getElementById('fullName');
            const email = document.getElementById('email');
            const msg = document.getElementById('message');
            const status = document.getElementById('formStatus');

            // Reset errors
            document.querySelectorAll('.error-message').forEach(el => el.textContent = '');

            if (name.value.trim().length < 2) {
                document.getElementById('nameError').textContent = 'Please enter your full name (at least 2 characters).';
                isValid = false;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email.value.trim())) {
                document.getElementById('emailError').textContent = 'Please enter a valid email address.';
                isValid = false;
            }

            if (msg.value.trim().length < 10) {
                document.getElementById('msgError').textContent = 'Message must be at least 10 characters long.';
                isValid = false;
            }

            if (isValid && status) {
                status.style.color = 'var(--accent-cyan)';
                status.textContent = 'Sending message...';

                setTimeout(() => {
                    status.style.color = 'var(--accent-green)';
                    status.textContent = 'Thank you! Your message has been successfully submitted.';
                    contactForm.reset();
                }, 1000);
            }
        });
    }
});