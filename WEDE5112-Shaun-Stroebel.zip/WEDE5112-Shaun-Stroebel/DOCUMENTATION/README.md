# 🎓 Portfolio Project: Part 3 — Apex Endurance Web Platform

> **Course Module:** Web App & Mobile Development (`WEDE5020` / `PIXD5112`)  
> **Student Name:** Shaun Stroebel  
> **Student ID:** ST10507489  
> **Submission Date:** November 2026  
> **Project Repository:** `Apex-Endurance-Hub`  
> **Live Deployment:** [Apex Endurance Live Site](https://yourdomain.netlify.app/)  

---

## 1. Project Overview & Multi-User Purpose

**Apex Endurance** is a responsive, multi-user web application engineered for long-distance running and cycling endurance athletes. The platform provides tailored environments for two distinct user personas:

1. **Athletes / End-Users:** Access precision pace calculators, half-distance split estimation engines, periodization training blueprints, 10 iconic global and local route profiles with full-screen Lightbox previews, and persistent gear checklists.
2. **Route Creators & Designers:** Utilize a dedicated CRUD studio to map out new endurance courses, define surface technicality, log elevation gains, and publish custom routes directly to the platform.

---

## 2. Directory Architecture & File Structure

The project has been organized into a clean, modular folder hierarchy separating HTML entry points, styling rules, client scripts, media assets, search engine directives, and formal academic documentation.

```text
Apex-Endurance/
├── html/
│   ├── index.html          # Landing Page & Dual-Role Workspace Launcher
│   ├── routes.html         # 10 Iconic Routes & Lightbox Modal Gallery
│   ├── calculator.html     # Pace, Speed & 50% Split Calculation Engine
│   ├── plans.html          # Periodization Plans & Persistent Gear Checklists
│   ├── creator.html        # Route Creator & Designer CRUD Studio
│   └── contact.html        # Contact Form with Client-Side AJAX Validation
├── css/
│   └── style.css           # Multi-Tier Responsive Stylesheet (em Breakpoints)
├── javascript/
│   └── script.js          # Dual-Role State, Calculator Logic, DOM & LocalStorage API
├── MEDIA/
│   ├── Images/             # Route Photographs & Background Visuals
│   └── Video/              # Platform Instructional Clips
├── robots.txt              # Search Engine Crawler Directives
├── sitemap.xml             # XML Site Structure for Crawlers
└── Documentation/
    ├── README.md           # Master Project Documentation
    └── CHANGELOG.md        # Detailed Revision & Version Log