# 📋 Project Changelog & Architectural Log

> **Project:** Apex Endurance — Multi-User Performance & Route Platform  
> **Module / Subject:** Web Development & Interactive Design  WEDE5112
> **Student Name:** Shaun Stroebel (ST10507489)  
> **Academic Year:** 2026  

---

## 🚀 Version Summary

| Version | Release Date | Key Milestone / Primary Focus |
| :--- | :--- | :--- |
| `v4.0.0` | Nov 2026 | Multi-Page Architecture, 10 Iconic Routes & Full Dual-Role Studio |
| `v3.2.0` | Nov 2026 | SEO Optimization (`robots.txt` & `sitemap.xml`) & Relative Breakpoint Security |
| `v3.1.0` | Oct 2026 | Interactive Lightbox Gallery & Dynamic Pace/Split Engine |
| `v3.0.0` | Oct 2026 | Dual-Role Architecture (Athletes vs. Route Creators) |
| `v2.0.0` | Sep 2026 | Responsive Grid Layout, Media Queries & Form Structure |
| `v1.0.0` | Aug 2026 | Initial Layout Prototype & Core CSS Styling |

---

## 📦 Detailed Release History

### `v4.0.0` — Multi-Page Architecture & Expanded Routes
`Release Date: November 2, 2026`

#### 🟢 Added
* **Multi-Page File Structure:** Separated single-page layout into distinct, dedicated HTML entry points:
  * `html/index.html` — Landing page and dual-role workspace launcher.
  * `html/routes.html` — Explore 10 world-class running and cycling routes.
  * `html/calculator.html` — Dynamic pace, speed, and 50% split metric engine.
  * `html/plans.html` — Periodization blueprints and interactive equipment checklists.
  * `html/creator.html` — Route Creator Studio for publishing custom courses.
  * `html/contact.html` — Contact and inquiry page with client-side AJAX validation.
* **10 Iconic Endurance Routes:** Expanded route database to 5 long-distance running courses and 5 endurance cycling passes:
  * 🏃 **Running:** Berlin Marathon, Peninsula Ultra, Boston Marathon, UTMB Alpine Loop, Comrades "Up Run".
  * 🚴 **Cycling:** Chapman's Peak Coastal Loop, Alpe d'Huez Ascent, Sa Calobra Winding Pass, Stelvio Pass, Shimanami Kaido Sea Way.

#### 🟡 Changed
* Refactored navigation headers across all HTML pages to maintain active link highlighting (`.nav-link.active`) dynamically.
* Enhanced `script.js` DOM listeners to safely guard against missing elements on single-purpose pages.

---

### `v3.2.0` — SEO Configuration & CSS Security Hardening
`Release Date: November 2, 2026`

#### 🟢 Added
* **Search Engine Optimization Assets:**
  * Created `robots.txt` in the root directory to direct search crawlers.
  * Created `sitemap.xml` mapping all public HTML endpoints with priority ratings and update frequencies.

#### 🛠️ Fixed & Hardened
* **CSS Syntax Repair:** Fixed 7 stylesheet syntax errors, including malformed media query comments and orphaned reset blocks.
* **Relative Breakpoints:** Replaced fixed `px` media query values with relative `em` breakpoints (`22.5em`, `48em`, `64em`, `90em`) to support small phones up to 4K displays.
* **Touch Security:** Added `touch-action: manipulation` and `-webkit-tap-highlight-color` to prevent double-tap delays and touch leaks on mobile devices.

---

### `v3.1.0` — Interactive Lightbox & Dynamic Pace Engine
`Release Date: October 28, 2026`

#### 🟢 Added
* **Pace & Split Engine:** JavaScript calculation logic converting distance and target finish duration into average speed (km/h), pace (min/km), and 50% split times.
* **Full-Screen Lightbox Modal:** Image click listener opening high-resolution terrain previews with smooth backdrop overlays and caption titles.
* **Persistent Checklists:** Saved interactive gear checklist states to `localStorage` so checked items persist on refresh.

---

### `v2.0.0` — Responsive Grid & Form Validation
`Release Date: September 15, 2026`

#### 🟢 Added
* **Client-Side Form Validation:** Real-time feedback for required fields, min-length checks, and regex email validation on the contact form.
* **Discipline Filters:** JavaScript DOM filtering showing/hiding cards by discipline (`All`, `Running`, `Cycling`).

---

### `v1.0.0` — Initial Base Prototype
`Release Date: August 20, 2026`

#### 🟢 Added
* Initial HTML structure and baseline CSS variables (`:root`) for dark-mode aesthetic styling.

---

## 🛠️ Technology Stack

* **Frontend:** Semantic HTML5, CSS3 (Flexbox, CSS Grid, Custom Properties, Fluid Clamp).
* **Scripting:** Vanilla JavaScript (ES6+, DOM Manipulation, LocalStorage API).
* **Assets & Icons:** FontAwesome 6.4.0, Unsplash CDN.
* **SEO & Compliance:** XML Sitemap 0.9, Standard `robots.txt`.